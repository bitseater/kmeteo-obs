#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

import os
import sys    
import signal
import gettext
import locale
from PyQt6.QtWidgets import QApplication

# Necesario para que el ejecutable encuentre los módulos
sys.path.insert(1, os.path.join('@pkgdatadir@'))

import mainwindow
from constants import APP_ID,LOCALE_DIR 
from config import get_settings, update_autostart

# Configurar gettext
locale.setlocale(locale.LC_ALL, '')
gettext.bindtextdomain(APP_ID, LOCALE_DIR)
gettext.textdomain(APP_ID)
_ = gettext.gettext

# TODO: Notificaciones

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName(APP_ID)
    app.setDesktopFileName(APP_ID)

    # Configurar estilo según plataforma
    if sys.platform == "win32":
        app.setStyle("Fusion")
    elif not os.environ.get("QT_QUICK_CONTROLS_STYLE"):
        os.environ["QT_QUICK_CONTROLS_STYLE"] = "org.kde.desktop"

    # Permitir cerrar la aplicación con Ctrl+C
    signal.signal(signal.SIGINT, signal.SIG_DFL)
        
    settings = get_settings()
    update_autostart(settings.value("startonboot", False, type=bool))
    window = mainwindow.MainWindow()
    sys.exit(app.exec())
