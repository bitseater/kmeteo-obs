#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.


from PyQt6.QtCore import Qt, QSettings, QTimer
from PyQt6.QtWidgets import QMainWindow, QWidget, QToolBar, QMessageBox, QSizePolicy, QMenu, QToolButton, QSystemTrayIcon, QApplication
from PyQt6.QtGui import QIcon, QAction
from constants import APP_ID
from widgets.icons import themed_icon
from widgets.settings import SettingsWindow
from widgets.today import get_icon, Today
from widgets.maps import Maps
import json
import gettext
import requests
_ = gettext.gettext 


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Configurar la ventana principal
        self.setWindowTitle(_("KMeteo"))

        # Crear una barra de herramientas
        self.toolbar = QToolBar(_("Main Toolbar"))
        self.toolbar.setMovable(False)
        self.toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.addToolBar(self.toolbar)

        # Añadir botones a la barra de herramientas con iconos simbólicos
        action_today = QAction(themed_icon("weather-clear-symbolic"), _("Today"), self)
        action_today.triggered.connect(self.show_today)
        self.toolbar.addAction(action_today)

        spacer_1 = QWidget()
        spacer_1.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.toolbar.addWidget(spacer_1)

        action_forecast = QAction(themed_icon("view-calendar-symbolic"), _("Forecast"), self)
        action_forecast.triggered.connect(self.forecast_action)
        self.toolbar.addAction(action_forecast)

        spacer_2 = QWidget()
        spacer_2.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.toolbar.addWidget(spacer_2)

        action_maps = QAction(themed_icon("map-globe-symbolic"), _("View maps"), self)
        action_maps.triggered.connect(self.maps_action)
        self.toolbar.addAction(action_maps)
        
        spacer_3 = QWidget()
        spacer_3.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.toolbar.addWidget(spacer_3)

        action_change = QAction(themed_icon("add-placemark-symbolic"), _("Change city"), self)
        action_change.triggered.connect(self.search_city)
        self.toolbar.addAction(action_change)

        spacer_4 = QWidget()
        spacer_4.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.toolbar.addWidget(spacer_4)

        # Añadir un menú desplegable al final de la barra de herramientas sin flecha
        menu_button = QToolButton(self)
        menu_button.setIcon(themed_icon("application-menu"))
        menu_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)  # Muestra el menú sin flecha
        menu = QMenu(self)
        menu.addAction(_("Settings"), self.open_settings)
        menu.addAction(_("Help"), self.show_help)
        menu.addAction(_("About"), self.show_about)
        menu_button.setMenu(menu)
        self.toolbar.addWidget(menu_button)
        
        # Crea un contenedor central
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        # Comprueba la configuración
        self.settings = QSettings(APP_ID, "kmeteo")
        self.interval = self.settings.value("interval", 7200, type=int)
        self.current_view = None
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.refresh_central_widget)
        self.refresh_timer.start(self.interval * 1000)

        if self.settings.contains("width") and self.settings.contains("height"):
            width = int(self.settings.value("width"))
            height = int(self.settings.value("height"))
            self.resize(width, height)
        else:
            self.resize(640, 480)
        
        # Crear icono en la bandeja del sistema
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(themed_icon("weather-clear"))  # Icono por defecto
        self.tray_icon.setToolTip(_("KMeteo"))
        
        # Menú del tray
        tray_menu = QMenu()
        tray_menu.addAction(_("Show"), self.show)
        tray_menu.addAction(_("Hide"), self.hide)
        tray_menu.addAction(_("Quit"), QApplication.quit)
        self.tray_icon.setContextMenu(tray_menu)
        
        self.tray_icon.activated.connect(self.tray_activated)
        self.tray_icon.show()
        
        self.load_or_search()

        # Mostrar u ocultar la ventana principal según la configuración de inicio minimizado
        if self.settings.value("minimized", False, type=bool):
            self.hide()
        else:
            self.show()
        
    def load_or_search(self):
        # Leer el array desde QSettings o autolocalizar si está habilitado
        self.settings.sync()
        if self._ensure_city():
            self.current_view = "today"
            stored_array = self.settings.value("city", "[]")
            my_city = json.loads(stored_array)
            print(my_city)
            self.setWindowTitle(my_city[2] + ", " + my_city[4] + " (" + my_city[3] + ")")
            from widgets.today import Today
            today_widget = Today()
            today_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
            today_widget.setContentsMargins(15, 15, 15, 15)
            self.central_widget.setLayout(today_widget)
            self.update_tray(today_widget.weather_data['temp'], today_widget.weather_data['icon'], today_widget.weather_data['description'])
        else:
            self.search_city()

    def _ensure_city(self):
        self.settings.sync()
        if self.settings.value("autoloc", False, type=bool):
            if self.auto_locate_city():
                return True
        if self.settings.contains("city") and self.settings.value("city") != "[]":
            return True
        return False

    def auto_locate_city(self):
        try:
            response = requests.get("http://ip-api.com/json", timeout=6)
            if response.status_code != 200:
                return False
            data = response.json()
            if data.get("status") != "success":
                return False

            lat = str(data.get("lat", ""))
            lon = str(data.get("lon", ""))
            name = data.get("city") or _("Unknown")
            country = data.get("countryCode", "")
            state = data.get("regionName", "")
            if not lat or not lon or not name:
                return False

            city_array = [lat, lon, name, country, state]
            self.settings.setValue("city", json.dumps(city_array))
            self.settings.sync()
            return True
        except requests.RequestException:
            return False

    def search_city(self):
        # Eliminar el contenido actual del widget central
        new_central = QWidget(self)
        self.setCentralWidget(new_central)
        self.central_widget = new_central

        # Crear una nueva instancia de City y configurarla como el widget central
        from widgets.city import City
        city_widget = City()
        city_widget.city_saved.connect(self.reload_mainwindow)
        city_widget.setAlignment(Qt.AlignmentFlag.AlignTop)
        city_widget.setContentsMargins(5, 5, 5, 5)
        self.current_view = "search"
        self.central_widget.setLayout(city_widget)
        self.tray_icon.setIcon(themed_icon("weather-clear-symbolic"))
        self.tray_icon.setToolTip(_("KMeteo\nSearching city..."))

    def reload_mainwindow(self):
        # Recargar la ventana principal
        self.settings.sync()
        new_central = QWidget(self)
        self.setCentralWidget(new_central)
        self.central_widget = new_central
        self.load_or_search()

    def show_today(self):
        if not self.settings.contains("city") or self.settings.value("city") == "[]":
            QMessageBox.warning(self, _("Today"), _("No city configured. Please select a city first."))
            self.search_city()
            return

        self.central_widget.deleteLater()
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        today_widget = Today()
        today_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        today_widget.setContentsMargins(15, 15, 15, 15)
        self.current_view = "today"
        self.central_widget.setLayout(today_widget)
        self.update_tray(today_widget.weather_data['temp'], today_widget.weather_data['icon'], today_widget.weather_data['description'])

    def refresh_central_widget(self):
        if self.current_view == "today":
            self.show_today()
        elif self.current_view == "maps":
            self.maps_action()
        elif self.current_view == "search":
            self.search_city()
        elif self.current_view == "forecast":
            self.forecast_action()
        else:
            self.load_or_search()

    def update_tray(self, temp, icon_code, description=""):
        icon_name = get_icon(icon_code)
        self.tray_icon.setIcon(QIcon.fromTheme(icon_name))
        # Obtener información de la ciudad desde configuración
        stored_array = self.settings.value("city", "[]")
        my_city = json.loads(stored_array)
        city_name = my_city[2] if len(my_city) > 2 else _("N/A")
        country = my_city[4] if len(my_city) > 4 else _("N/A")

        units = self.settings.value("units", "metric")
        unit_symbol = "°C"
        if units == "imperial":
            unit_symbol = "°F"
        elif units == "standard":
            unit_symbol = "K"

        tooltip_text = f"{city_name}, {country}\n{description}\n{_('Temperature')}: {temp} {unit_symbol}"
        self.tray_icon.setToolTip(tooltip_text)

    def maps_action(self):
        # Mostrar un widget con una URL para mapas
        self.central_widget.deleteLater()
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        maps_widget = Maps()
        maps_widget.setAlignment(Qt.AlignmentFlag.AlignTop)
        maps_widget.setContentsMargins(5, 5, 5, 5)
        self.current_view = "maps"
        self.central_widget.setLayout(maps_widget)

    def forecast_action(self):
        if not self.settings.contains("city") or self.settings.value("city") == "[]":
            QMessageBox.warning(self, _("Forecast"), _("No city configured. Please select a city first."))
            self.search_city()
            return

        self.central_widget.deleteLater()
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        from widgets.forecast import Forecast
        forecast_widget = Forecast()
        forecast_widget.setContentsMargins(15, 15, 15, 15)
        self.current_view = "forecast"
        self.central_widget.setLayout(forecast_widget)

    def open_settings(self):
        # Abre la ventana de configuración SettingsWindow
        dlg = SettingsWindow(self)
        if dlg.exec():
            self.settings.sync()
            self.interval = self.settings.value("interval", 7200, type=int)
            self.refresh_timer.setInterval(self.interval * 1000)
            self.reload_mainwindow()
            QMessageBox.information(self, _("Settings"), _("Settings saved successfully."))

    def show_help(self):
        # Método para mostrar la ayuda
        from widgets.help import HelpDialog
        help_dialog = HelpDialog(self)
        help_dialog.exec()

    def show_about(self):
        # Método para mostrar el diálogo "Acerca de"
        from widgets.about import AboutDialog
        about_dialog = AboutDialog(self)
        about_dialog.exec()

    def tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            # Clic izquierdo: alterna entre maximizar y minimizar
            if not self.isVisible():
                # Si está oculta, mostrarla y maximizar
                self.showMaximized()
                self.raise_()
                self.activateWindow()
            elif self.isMaximized():
                # Si está maximizada, minimizar
                self.showMinimized()
            else:
                # Si está restaurada, maximizar
                self.showMaximized()
        elif reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show()
            self.raise_()
            self.activateWindow()
