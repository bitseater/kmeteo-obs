#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

from PyQt6.QtWidgets import QDialog, QGridLayout, QLabel, QComboBox, QPushButton
from PyQt6.QtCore import Qt, QSettings
from constants import APP_ID
from widgets.toggle import Toggle
from config import update_autostart
import gettext
_ = gettext.gettext

class SettingsWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("Configuration"))
        self.setMinimumWidth(450)
        self.settings = QSettings(APP_ID, "kmeteo")
        self.settings.sync()

        layout = QGridLayout()
        layout.setContentsMargins(20, 20, 20, 20)

        # Selector de unidades
        units_label = QLabel(_("Units:"))
        self.units_combo = QComboBox()
        units_options = [
            ("metric", _("Metric (°C, m/s)")),
            ("imperial", _("Imperial (°F, mph)")),
            ("standard", _("Standard (K, m/s)")),
        ]
        for value, text in units_options:
            self.units_combo.addItem(text, value)
        current_units = self.settings.value("units", "metric")
        idx = self.units_combo.findData(current_units)
        if idx >= 0:
            self.units_combo.setCurrentIndex(idx)
        layout.addWidget(units_label, 0, 0, 1, 1, Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.units_combo, 0, 1, 1, 1, Qt.AlignmentFlag.AlignLeft)

        # Selector de minimizado
        minimized_label = QLabel(_("Minimized on startup:"))
        self.minimized_toggle = Toggle()
        minimized_enabled = self.settings.value("minimized", False, type=bool)
        self.minimized_toggle.setChecked(minimized_enabled)
        layout.addWidget(minimized_label, 1, 0, 1, 1, Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.minimized_toggle, 1, 1, 1, 1, Qt.AlignmentFlag.AlignLeft)

        # Guardar el estado del toggle
        self.minimized_toggle_state = minimized_enabled
        self.minimized_toggle.stateChanged.connect(self.on_minimized_toggle_changed)

        # Selector de intervalo de actualización
        interval_label = QLabel(_("Update interval (seconds):"))
        self.interval_combo = QComboBox()
        interval_options = [
            (7200, _("2 hours")),
            (21600, _("6 hours")),
            (43200, _("12 hours")),
        ]
        for value, text in interval_options:
            self.interval_combo.addItem(text, value)
        current_interval = self.settings.value("interval", 7200, type=int)
        idx = self.interval_combo.findData(current_interval)
        if idx >= 0:
            self.interval_combo.setCurrentIndex(idx)
        layout.addWidget(interval_label, 2, 0, 1, 1, Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.interval_combo, 2, 1, 1, 1, Qt.AlignmentFlag.AlignLeft)

        # Selector de autolocalización
        autoloc_label = QLabel(_("Automatic location:"))
        self.autoloc_toggle = Toggle()
        autoloc_enabled = self.settings.value("autoloc", True, type=bool)
        self.autoloc_toggle.setChecked(autoloc_enabled)
        layout.addWidget(autoloc_label, 3, 0, 1, 1, Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.autoloc_toggle, 3, 1, 1, 1, Qt.AlignmentFlag.AlignLeft)

        # Guardar el estado del toggle de autoloc
        self.autoloc_toggle_state = autoloc_enabled
        self.autoloc_toggle.stateChanged.connect(self.on_autoloc_toggle_changed)

        # Selector de inicio automático (start on boot)
        startonboot_label = QLabel(_("Start on boot:"))
        self.startonboot_toggle = Toggle()
        startonboot_enabled = self.settings.value("startonboot", False, type=bool)
        self.startonboot_toggle.setChecked(startonboot_enabled)
        layout.addWidget(startonboot_label, 4, 0, 1, 1, Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.startonboot_toggle, 4, 1, 1, 1, Qt.AlignmentFlag.AlignLeft)

        # Guardar el estado del toggle de start on boot
        self.startonboot_toggle_state = startonboot_enabled
        self.startonboot_toggle.stateChanged.connect(self.on_startonboot_toggle_changed)

        # Botón guardar
        save_btn = QPushButton(_("Save"))
        save_btn.clicked.connect(self.save_settings)
        layout.addWidget(save_btn, 5, 1, 1, 1, alignment=Qt.AlignmentFlag.AlignLeft)

        self.setLayout(layout)

    def on_minimized_toggle_changed(self, state):
        self.minimized_toggle_state = bool(state)

    def on_autoloc_toggle_changed(self, state):
        self.autoloc_toggle_state = bool(state)

    def on_startonboot_toggle_changed(self, state):
        self.startonboot_toggle_state = bool(state)

    def save_settings(self):
        self.settings.setValue("units", self.units_combo.currentData())
        self.settings.remove("theme")
        self.settings.setValue("minimized", self.minimized_toggle_state)
        self.settings.setValue("interval", self.interval_combo.currentData())
        self.settings.setValue("autoloc", self.autoloc_toggle_state)
        self.settings.setValue("startonboot", self.startonboot_toggle_state)
        update_autostart(self.startonboot_toggle_state)
        self.settings.sync()

        self.accept()
