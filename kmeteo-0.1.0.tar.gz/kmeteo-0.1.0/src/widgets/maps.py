#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

from urllib.parse import quote_plus

from PyQt6.QtCore import Qt, QSettings, QUrl
from PyQt6.QtWidgets import QVBoxLayout, QLabel, QWidget, QSizePolicy
from constants import APP_ID
import json
import gettext
_ = gettext.gettext

try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    WEB_ENGINE_AVAILABLE = True
except ImportError:
    QWebEngineView = None
    WEB_ENGINE_AVAILABLE = False

class Maps(QVBoxLayout):
    def __init__(self):
        super().__init__()

        self.settings = QSettings(APP_ID, "kmeteo")
        self.setContentsMargins(0, 0, 0, 0)
        self.setSpacing(0)

        city = self._load_city()
        url = self._build_url(city)

        if WEB_ENGINE_AVAILABLE:
            web_view = QWebEngineView()
            web_view.setUrl(QUrl(url))
            web_view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            self.addWidget(web_view)
        else:
            label = QLabel()
            label.setTextFormat(Qt.TextFormat.RichText)
            label.setText(f'<a href="{url}">{url}</a>')
            label.setOpenExternalLinks(True)
            label.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
            self.addWidget(label)

    def _load_city(self):
        if self.settings.contains("city") and self.settings.value("city") != "[]":
            stored_array = self.settings.value("city", "[]")
            try:
                my_city = json.loads(stored_array)
                if len(my_city) >= 5:
                    return {
                        "lat": my_city[0],
                        "lon": my_city[1],
                        "name": my_city[2],
                        "state": my_city[3],
                        "country": my_city[4],
                    }
            except (TypeError, ValueError):
                pass
        return None

    def _build_url(self, city):
        plab = _("Precipitation")
        pslab = _("Pressure")
        rlab = _("Radar")
        tlab = _("Temperature")
        wlab = _("Wind")
        p36 = _("Play 3600x")
        pau = _("Pause")

        params = (
            f"plab={quote_plus(plab)}",
            f"pslab={quote_plus(pslab)}",
            f"rlab={quote_plus(rlab)}",
            f"tlab={quote_plus(tlab)}",
            f"wlab={quote_plus(wlab)}",
            f"p36={quote_plus(p36)}",
            f"pau={quote_plus(pau)}",
        )
        config = "?" + "&".join(params)

        if city is not None:
            endurl = f"#5/{self._db_to_str(city['lat'])}/{self._db_to_str(city['lon'])}"
        else:
            endurl = ""

        return "https://bitseater.gitlab.io/meteomap/meteomap.html" + config + endurl

    def _db_to_str(self, value):
        return str(value)
