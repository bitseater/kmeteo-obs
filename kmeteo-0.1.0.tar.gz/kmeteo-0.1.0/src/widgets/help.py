#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.


from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout, QGroupBox, QPushButton, QHBoxLayout, QScrollArea, QWidget

import gettext
_ = gettext.gettext

class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("Help - KMeteo"))
        self.setMinimumWidth(500)
        self.setMinimumHeight(600)

        # Crear un scroll area para que el contenido sea desplazable
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # Título principal
        label_title = QLabel("<h2>KMeteo - Weather Application</h2>")
        label_subtitle = QLabel(_("A weather and forecast application developed with Python & Qt"))
        layout.addWidget(label_title)
        layout.addWidget(label_subtitle)

        # Sección de características
        label_features = QLabel("<h3>Features</h3>")
        layout.addWidget(label_features)

        features_group = QGroupBox()
        features_layout = QVBoxLayout(features_group)

        features = [
            (_("Current Weather"), _("View current temperature, pressure, wind speed and direction, sunrise and sunset times.")),
            (_("Hourly Forecast"), _("Check the weather forecast for the next hours.")),
            (_("Daily Forecast"), _("View the weather forecast for the next days.")),
            (_("Weather Maps"), _("Visualize weather information on interactive maps with weather layers.")),
            (_("City Selection"), _("Choose your city and change it anytime you want.")),
            (_("Units Configuration"), _("Select your preferred temperature units (Celsius, Fahrenheit, or Kelvin).")),
            (_("System Tray Indicator"), _("Quick access to current weather information from the system tray.")),
            (_("Auto-location"), _("Enable automatic city detection based on your IP address.")),
        ]

        for feature_title, feature_desc in features:
            feature_label = QLabel(f"<b>{feature_title}:</b> {feature_desc}")
            feature_label.setWordWrap(True)
            features_layout.addWidget(feature_label)

        layout.addWidget(features_group)

        # Sección de inicio rápido
        label_quick = QLabel("<h3>Quick Start</h3>")
        layout.addWidget(label_quick)

        quick_group = QGroupBox()
        quick_layout = QVBoxLayout(quick_group)

        quick_steps = [
            (_("Step 1: Select a City"), _("Click the 'Change city' button in the toolbar to search and select your city.")),
            (_("Step 2: View Current Weather"), _("Click the 'Today' button to see the current weather information for your city.")),
            (_("Step 3: Check Forecast"), _("Use the 'Forecast' button to view hourly and daily weather forecasts.")),
            (_("Step 4: View Maps"), _("Click 'View maps' to see weather information on interactive maps.")),
            (_("Step 5: Configure Settings"), _("Open the menu (top-right) and click 'Settings' to customize units and other options.")),
        ]

        for step_title, step_desc in quick_steps:
            step_label = QLabel(f"<b>{step_title}:</b><br/>{step_desc}")
            step_label.setWordWrap(True)
            quick_layout.addWidget(step_label)

        layout.addWidget(quick_group)

        # Sección de datos
        label_data = QLabel("<h3>Data Source</h3>")
        layout.addWidget(label_data)

        data_label = QLabel(_("Weather data is provided by <b>OpenWeatherMap API</b> (https://openweathermap.org/)."))
        data_label.setWordWrap(True)
        layout.addWidget(data_label)

        # Separador
        layout.addSpacing(20)

        # Botón de cerrar
        btn_close = QPushButton(_("Close"))
        btn_close.setDefault(True)
        btn_close.setFixedWidth(100)
        btn_close.clicked.connect(self.accept)
        
        # Crear un layout horizontal para alinear el botón a la derecha
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)

        # Agregar el widget principal al scroll area
        scroll_area.setWidget(main_widget)
        
        # Crear el layout principal del diálogo
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(scroll_area)
        
        self.setLayout(dialog_layout)
