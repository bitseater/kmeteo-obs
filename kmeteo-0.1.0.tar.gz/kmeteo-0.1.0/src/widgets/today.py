#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

from PyQt6.QtCore import Qt, QSettings
from PyQt6.QtGui import QIcon, QPainter, QPalette, QPixmap
from PyQt6.QtWidgets import QGridLayout, QLabel,QMessageBox, QWidget, QHBoxLayout, QVBoxLayout, QFrame

from constants import OWN_API_KEY, APP_ID
import datetime
import requests
import json
import locale
import gettext
_ = gettext.gettext

class Today(QHBoxLayout):

    def __init__(self):
        super().__init__()

        # Configuración de QSettings
        self.settings = QSettings(APP_ID, "kmeteo")

        # Obtener datos de la ciudad guardada
        self.my_city = []
        if self.settings.contains("city") and self.settings.value("city") != "[]":
            stored_array = self.settings.value("city", "[]")
            self.my_city = json.loads(stored_array)
        units = self.settings.value("units", "metric")

        unit_symbol = "°C"
        if units == "imperial":
            unit_symbol = "°F"
        elif units == "standard":
            unit_symbol = "K"

        # Obtener el idioma del sistema o usar 'en' por defecto
        lang = locale.getdefaultlocale()[0]
        if lang:
            lang = lang.split('_')[0]
        else:
            lang = "en"
        
        # Hacer consulta WEATHER a la API
        api_url = "http://api.openweathermap.org/data/2.5/weather"
        params = {
            "lat": self.my_city[0],
            "lon": self.my_city[1],
            "appid": OWN_API_KEY,
            "units": units,
            "lang": lang,
        }

        print(units, lang)  # Para depurar

        response = requests.get(api_url, params=params)
        if response.status_code == 200:
            data = response.json()
            # print(data) # Si se necesita depurar
            self.weather_data = {
                "temp": round(data["main"]["temp"]),
                "feel_like": round(data["main"]["feels_like"]),
                "humidity": data["main"]["humidity"],
                "pressure": data["main"]["pressure"],
                "wind_speed": data["wind"]["speed"],
                "wind_deg": data["wind"]["deg"],
                "description": data["weather"][0]["description"],
                "icon": data["weather"][0]["icon"],
                "visibility": data["visibility"],
                "sunrise": data["sys"]["sunrise"],
                "sunset": data["sys"]["sunset"],
            }
        else:
            QMessageBox.critical(None, _("Error"), _("Failed to fetch weather data."))
            return

        # Hacer consulta FORECAST a la API
        api_f_url = "http://api.openweathermap.org/data/2.5/forecast"
        paramsf = {
            "lat": self.my_city[0],
            "lon": self.my_city[1],
            "appid": OWN_API_KEY,
            "cnt": 8,
            "units": units,
            "lang": lang,
        }

        responsef = requests.get(api_f_url, params=paramsf)
        if responsef.status_code == 200:
            dataf = responsef.json()
            # print(data) # Si se necesita depurar
            self.forecast_data = [
                {
                    "hour": unix_utc_to_local(item["dt"]),
                    "temp": round(item["main"]["temp"]),
                    "icon": item["weather"][0]["icon"],
                    "description": item["weather"][0]["description"],
                }
                for item in dataf["list"]
            ]
        else:
            QMessageBox.critical(None, _("Error"), _("Failed to fetch weather data."))
            return


        # Crear contenido
        temp_label = QLabel()
        temp_label.setTextFormat(Qt.TextFormat.RichText)
        temp_label.setText(_("<h1>{temp} {unit}</h1>").format(temp=self.weather_data['temp'], unit=unit_symbol))

        feel_like_label = QLabel()
        feel_like_label.setTextFormat(Qt.TextFormat.RichText)
        feel_like_label.setText(_("<i>Feels like: {temp} {unit}</i>").format(temp=self.weather_data['feel_like'], unit=unit_symbol))

        description_label = QLabel()
        description_label.setTextFormat(Qt.TextFormat.RichText)
        description_label.setText(f"<h3>{self.weather_data['description']}</h3>")

        icon_label = QLabel()
        icon = QIcon.fromTheme(get_icon(self.weather_data["icon"]))
        icon_pixmap = icon.pixmap(64, 64)
        icon_label.setPixmap(icon_pixmap)

        humidity_label = label_with_icon(f"{APP_ID}-humidity-symbolic", f"<i>{_('Humidity')}: {self.weather_data['humidity']}%</i>")
        pressure_label = label_with_icon(f"{APP_ID}-barometer-symbolic", f"<i>{_('Pressure')}: {self.weather_data['pressure']} hPa</i>")
        wind_label = label_with_icon(f"{APP_ID}-wind-symbolic", f"<i>{_('Wind speed')}: {self.weather_data['wind_speed']} m/s</i>")
        winddeg_label = label_with_icon(f"{APP_ID}-wind-symbolic", f"<i>{_('Wind direction')}: {cardinal(self.weather_data['wind_deg'])}</i>")
        visibility_label = label_with_icon(f"{APP_ID}-view-symbolic", f"<i>{_('Visibility')}: {self.weather_data['visibility']} m</i>")
        sunrise_local = unix_utc_to_local(self.weather_data['sunrise'])
        sunrise_label = label_with_icon(f"{APP_ID}-sunrise-symbolic", f"<i>{_('Sunrise: {time} UTC').format(time=sunrise_local)}</i>")
        sunset_local = unix_utc_to_local(self.weather_data['sunset'])
        sunset_label = label_with_icon(f"{APP_ID}-sunset-symbolic", f"<i>{_('Sunset: {time} UTC').format(time=sunset_local)}</i>")

        # Fase lunar
        hoy = datetime.datetime.now()
        mp = moonphase(hoy.year, hoy.month, hoy.day)

        fases = {
            0: (_("New Moon"), f"{APP_ID}-moon-new-symbolic"),
            1: (_("Waxing Crescent"), f"{APP_ID}-moon-waxing-crescent-symbolic"),
            2: (_("First Quarter"), f"{APP_ID}-moon-quarter-symbolic"),
            3: (_("Waxing Gibbous"), f"{APP_ID}-moon-waxing-gibbous-symbolic"),
            4: (_("Full Moon"), f"{APP_ID}-moon-full-symbolic"),
            5: (_("Waning Gibbous"), f"{APP_ID}-moon-waning-gibbous-symbolic"),
            6: (_("Last Quarter"), f"{APP_ID}-moon-last-quarter-symbolic"),
            7: (_("Waning Crescent"), f"{APP_ID}-moon-waning-crescent-symbolic"),
        }
        moon_text, moon_icon_name = fases.get(mp, (_("Error"), None))

        moon_label = QLabel()
        moon_label.setTextFormat(Qt.TextFormat.RichText)
        moon_label.setText(f"<i>{_('Lunar phase')}: {moon_text}</i>")

        moon_icon_label = QLabel()
        if moon_icon_name:
            moon_icon_pixmap = symbolic_icon_pixmap(moon_icon_name, 24, moon_icon_label)
            moon_icon_label.setPixmap(moon_icon_pixmap)

        # --- Layout izquierdo (Grid) ---
        left_grid = QGridLayout()
        left_grid.setVerticalSpacing(10)
        left_grid.setHorizontalSpacing(10)

        # Título y datos principales en el grid izquierdo
        left_grid.addWidget(temp_label, 0, 0, 1, 1, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(feel_like_label, 1, 0, 1, 1, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(description_label, 2, 0, 1, 1, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(icon_label, 0, 1, 3, 1, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(humidity_label, 3, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)    
        left_grid.addWidget(pressure_label, 4, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(wind_label, 5, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(winddeg_label, 6, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(visibility_label, 7, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(sunrise_label, 8, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(sunset_label, 9, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(QWidget(), 10, 0, 1, 2)
        left_grid.addWidget(moon_label, 11, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        left_grid.addWidget(moon_icon_label, 11, 2, 1, 1, Qt.AlignmentFlag.AlignLeft)

         # Widget contenedor para el grid izquierdo
        left_widget = QWidget()
        left_widget.setLayout(left_grid)
        # left_widget.setSizePolicy(left_widget.sizePolicy().horizontalPolicy(), left_widget.sizePolicy().verticalPolicy())

        # --- Línea vertical ---
        vline = QFrame()
        vline.setFrameShape(QFrame.Shape.VLine)
        vline.setLineWidth(2)
        vline.setMidLineWidth(1)

        # --- Layout derecho (VBox) ---
        right_vbox = QVBoxLayout()
        right_vbox.setSpacing(5)
        right_vbox.addStretch(1)
        # Añadir pronóstico horario
        for forecast in self.forecast_data:
            forecast_layout = QHBoxLayout()
            forecast_layout.setSpacing(10)
            forecast_layout.setContentsMargins(0, 0, 0, 0)

            hour_label = QLabel(forecast["hour"])
            hour_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

            icon_label = QLabel()
            icon = QIcon.fromTheme(get_icon(forecast["icon"]))
            icon_pixmap = icon.pixmap(24, 24)
            icon_label.setPixmap(icon_pixmap)
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            icon_label.setToolTip(forecast["description"])

            temp_label = QLabel(f"{forecast['temp']} {unit_symbol}")
            temp_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

            forecast_layout.addWidget(hour_label,stretch=2)
            forecast_layout.addWidget(icon_label,stretch=1)
            forecast_layout.addWidget(temp_label,stretch=2)

            forecast_widget = QWidget()
            forecast_widget.setLayout(forecast_layout)
            forecast_widget.setFixedHeight(36)  # Altura uniforme para todas las filas

            right_vbox.addWidget(forecast_widget)
        right_widget = QWidget()
        right_widget.setLayout(right_vbox)

        # Añadir a principal layout
        self.addWidget(left_widget, stretch=1, alignment=Qt.AlignmentFlag.AlignCenter)
        self.addWidget(vline)
        self.addWidget(right_widget, stretch=1, alignment=Qt.AlignmentFlag.AlignCenter)

def get_icon(icon_code):
    """
    Maps OpenWeatherMap icon codes to local icon names.
    """
    icon_map = {
        "01d": "weather-clear",
        "01n": "weather-clear-night",
        "02d": "weather-few-clouds",
        "02n": "weather-few-clouds-night",
        "03d": "weather-clouds",
        "03n": "weather-clouds-night",
        "04d": "weather-overcast",
        "04n": "weather-overcast",
        "09d": "weather-showers-scattered",
        "09n": "weather-showers-scattered-night",
        "10d": "weather-showers",
        "10n": "weather-showers-night",
        "11d": "weather-storm",
        "11n": "weather-storm-night",
        "13d": "weather-snow",
        "13n": "weather-snow-night",
        "50d": "weather-fog",
        "50n": "weather-fog"
    }
    return icon_map.get(icon_code, icon_code)

def unix_utc_to_local(unix_time):
    """
    Convierte un timestamp UNIX UTC a hora local (timezone-aware) en formato HH:MM.
    """
    utc_dt = datetime.datetime.fromtimestamp(unix_time, tz=datetime.timezone.utc)
    local_dt = utc_dt.astimezone()  # Convierte a la zona horaria local del sistema
    return local_dt.strftime("%H:%M")

def cardinal(grados):
    """
    Convierte grados a dirección cardinal.
    """
    val = int((grados / 22.5) + 0.5)
    arr = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
           "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
    index = val % 16
    return _(arr[index])

def moonphase(y, m, d):
    """
    Calcula la fase lunar (0-7), exacto a 1 segmento.
    0 => luna nueva, 4 => luna llena.
    Adaptado de http://www.voidware.com/moon_phase.htm y http://jivebay.com/calculating-the-moon-phase/
    """
    if m < 3:
        y -= 1
        m += 12
    m += 1
    c = 365.25 * y
    e = 30.6 * m
    jd = c + e + d - 694039.09  # días transcurridos
    jd = jd / 29.5305882        # ciclo lunar (29.53 días)
    b = int(jd)                 # parte entera
    jd -= b                     # parte fraccionaria
    f = int(round(jd * 8))
    if f == 8:
        f = 0
    return f

def label_with_icon(icon_name, text, icon_size=22):
    layout = QHBoxLayout()
    icon_label = QLabel()
    pixmap = symbolic_icon_pixmap(icon_name, icon_size, icon_label)
    icon_label.setPixmap(pixmap)
    label = QLabel()
    label.setTextFormat(Qt.TextFormat.RichText)
    label.setText(text)
    layout.addWidget(icon_label)
    layout.addWidget(label)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(6)
    widget = QWidget()
    widget.setLayout(layout)
    return widget


def symbolic_icon_pixmap(icon_name, icon_size, widget):
    """Devuelve un icono simbólico con el color de texto del tema activo."""
    pixmap = QIcon.fromTheme(icon_name).pixmap(icon_size, icon_size)
    if pixmap.isNull():
        return pixmap

    colored_pixmap = QPixmap(pixmap.size())
    colored_pixmap.fill(Qt.GlobalColor.transparent)

    painter = QPainter(colored_pixmap)
    painter.drawPixmap(0, 0, pixmap)
    painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
    painter.fillRect(
        colored_pixmap.rect(),
        widget.palette().color(QPalette.ColorRole.WindowText),
    )
    painter.end()
    return colored_pixmap
