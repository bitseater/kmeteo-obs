#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

from PyQt6.QtCore import Qt, QSettings
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QVBoxLayout, QHBoxLayout, QLabel, QWidget, QMessageBox, QFrame

from constants import OWN_API_KEY, APP_ID
from widgets.today import get_icon
import requests
import json
import datetime
import locale
import gettext
from collections import defaultdict

_ = gettext.gettext

class Forecast(QVBoxLayout):
    def __init__(self):
        super().__init__()

        # Configuración de QSettings
        self.settings = QSettings(APP_ID, "kmeteo")

        # Obtener datos de la ciudad guardada
        self.my_city = []
        if self.settings.contains("city") and self.settings.value("city") != "[]":
            stored_array = self.settings.value("city", "[]")
            self.my_city = json.loads(stored_array)
        else:
            return

        units = self.settings.value("units", "metric")
        # Obtener el idioma del sistema o usar 'en' por defecto
        lang = locale.getdefaultlocale()[0]
        if lang:
            lang = lang.split('_')[0]
        else:
            lang = "en"

        # Hacer consulta FORECAST a la API (5 días / 3 horas)
        api_url = "http://api.openweathermap.org/data/2.5/forecast"
        params = {
            "lat": self.my_city[0],
            "lon": self.my_city[1],
            "appid": OWN_API_KEY,
            "units": units,
            "lang": lang,
        }

        try:
            response = requests.get(api_url, params=params)
            if response.status_code == 200:
                data = response.json()
                self._process_forecast_data(data)
                self._build_ui()
            else:
                QMessageBox.critical(None, _("Error"), _("Failed to fetch forecast data."))
        except requests.RequestException as e:
            QMessageBox.critical(None, _("Error"), f"{_('Request failed')}: {e}")

    def _process_forecast_data(self, data):
        # Agrupar datos por día
        daily_data = defaultdict(lambda: {"temps": [], "icons": [], "descriptions": []})
        
        for item in data["list"]:
            # Convertir timestamp a objeto datetime local
            dt = datetime.datetime.fromtimestamp(item["dt"], tz=datetime.timezone.utc).astimezone()
            date_key = dt.date()
            
            daily_data[date_key]["temps"].append(item["main"]["temp"])
            
            # Guardamos el icono y descripción con su distancia a mediodía (12:00)
            # para elegir el tiempo más representativo del día
            hour_dist = abs(dt.hour - 12)
            daily_data[date_key]["icons"].append((hour_dist, item["weather"][0]["icon"]))
            daily_data[date_key]["descriptions"].append((hour_dist, item["weather"][0]["description"]))

        self.forecast_results = []
        for date_key in sorted(daily_data.keys()):
            stats = daily_data[date_key]
            
            # Seleccionar icono y descripción más cercanos a mediodía
            best_icon = min(stats["icons"], key=lambda x: x[0])[1]
            best_desc = min(stats["descriptions"], key=lambda x: x[0])[1]
            
            self.forecast_results.append({
                "date": date_key.strftime(_("%a, %d %b")),
                "temp_max": round(max(stats["temps"])),
                "temp_min": round(min(stats["temps"])),
                "icon": best_icon,
                "description": best_desc
            })

    def _build_ui(self):
        units = self.settings.value("units", "metric")
        temp_unit = "°C"
        if units == "imperial":
            temp_unit = "°F"
        elif units == "standard":
            temp_unit = "K"

        title_label = QLabel(_("Forecast for the next days"))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 5px; margin-top: 20px;")
        self.addWidget(title_label)

        for day in self.forecast_results:
            row_widget = QWidget()
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(15, 8, 15, 8)
            
            row_layout.addStretch(1)
            
            date_label = QLabel(day["date"])
            date_label.setFixedWidth(110)
            date_label.setStyleSheet("font-weight: bold; font-size: 14px;")
            
            icon_label = QLabel()
            icon = QIcon.fromTheme(get_icon(day["icon"]))
            icon_label.setPixmap(icon.pixmap(32, 32))
            icon_label.setToolTip(day["description"].capitalize())
            icon_label.setFixedWidth(40)
            
            desc_label = QLabel(day["description"].capitalize())
            desc_label.setStyleSheet("font-style: italic;")
            desc_label.setFixedWidth(160)
            
            temp_label = QLabel(f"{day['temp_max']} / {day['temp_min']} {temp_unit}")
            temp_label.setFixedWidth(100)
            temp_label.setStyleSheet("font-weight: bold;")

            row_layout.addWidget(date_label)
            row_layout.addWidget(icon_label)
            row_layout.addWidget(desc_label)
            row_layout.addWidget(temp_label)
            
            row_layout.addStretch(1)
            
            self.addWidget(row_widget)
            
        self.addStretch(1)
