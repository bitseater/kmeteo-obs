#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.


from PyQt6.QtCore import Qt, QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout, QGroupBox, QPushButton, QHBoxLayout, QWidget

from constants import VERSION
from widgets.icons import themed_icon
import gettext
_ = gettext.gettext


class AboutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("About KMeteo"))
        self.setMinimumWidth(350)

        layout = QVBoxLayout(self)

        group = QGroupBox()
        group_layout = QVBoxLayout(group)

        label_app = QLabel(f"<h3>KMeteo {VERSION}</h3>")
        label_resume = QLabel(_("Weather and Forecast application developed with Python & Qt."))
        label_license = QLabel(_("License: GPLv3"))
        website_url = "https://gitlab.com/bitseater/kmeteo"
        label_website = QLabel(_("Website: {link}").format(link=f'<a href="{website_url}">{_("KMeteo on Gitlab")}</a>'))
        label_website.setOpenExternalLinks(True)

        group_layout.addWidget(label_app)
        group_layout.addWidget(label_resume)
        group_layout.addWidget(label_license)
        group_layout.addWidget(label_website)
        group.setLayout(group_layout)

        layout.addWidget(group)

        label_title2 = QLabel(_("Author"))
        layout.addWidget(label_title2)

        author = QGroupBox()
        author_layout = QVBoxLayout(author)

        label_author = line_with_mail(_("Developed by Carlos Suárez"), "bitseater@gmail.com")
        author_layout.addWidget(label_author)

        layout.addWidget(author)

        label_title3 = QLabel(_("Translators"))
        layout.addWidget(label_title3)

        translators = QGroupBox()
        translators_layout = QVBoxLayout(translators)

        # Lista de idiomas disponibles en la carpeta po/
        langs = [
            ("(DE) Carlos Suárez", "bitseater@gmail.com"),
            ("(EN) Carlos Suárez", "bitseater@gmail.com"),
            ("(ES) Carlos Suárez", "bitseater@gmail.com"),
            ("(FR) Carlos Suárez", "bitseater@gmail.com"),
            ("(IT) Carlos Suárez", "bitseater@gmail.com"),           
            ("(PT) Carlos Suárez", "bitseater@gmail.com"),
        ]

        for lang_text, email in langs:
            translators_layout.addWidget(line_with_mail(lang_text, email))

        layout.addWidget(translators)

        btn_close = QPushButton(_("Close"))
        btn_close.setDefault(True)
        btn_close.setFixedWidth(100)
        btn_close.clicked.connect(self.accept)
        
        # Crear un layout horizontal para alinear el botón a la derecha
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)

        self.setLayout(layout)


def line_with_mail(text, url=None):
    widget = QWidget()
    layout = QHBoxLayout(widget)
    layout.setContentsMargins(0, 0, 0, 0)
    text_label = QLabel(text)
    layout.addWidget(text_label, alignment=Qt.AlignmentFlag.AlignLeft)
    layout.addStretch()
    icon_button = QPushButton()
    icon_button.setIcon(themed_icon("mail-folder-sent-symbolic"))
    icon_button.setFlat(True)
    icon_button.setCursor(Qt.CursorShape.PointingHandCursor)
    icon_button.setFixedSize(22, 22)
    if url:
        def open_url():
            QDesktopServices.openUrl(QUrl(f"mailto:{url}"))
        icon_button.clicked.connect(open_url)
    layout.addWidget(icon_button, alignment=Qt.AlignmentFlag.AlignRight)
    return widget
