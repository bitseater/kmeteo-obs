#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.


from PyQt6.QtCore import Qt, QSettings, pyqtSignal
from PyQt6.QtGui import QStandardItem, QStandardItemModel
from PyQt6.QtWidgets import QGridLayout, QLabel,QLineEdit, QPushButton, QHeaderView, QMessageBox, QTableView

from constants import OWN_API_KEY, APP_ID
import requests
import json
import gettext
_ = gettext.gettext


class City(QGridLayout):
    # Señal para notificar que los datos han sido guardados
    city_saved = pyqtSignal()
    
    def __init__(self):
        super().__init__()

        # Configuración de QSettings
        self.settings = QSettings(APP_ID, "kmeteo")

        # Crea contenido
        label_city = QLabel()
        label_city.setText(_("Search your city:"))
        
        self.city_search = QLineEdit()
        self.city_search.setPlaceholderText(_("Enter city name"))
        self.city_search.setClearButtonEnabled(True)
        self.city_search.setMaxLength(30)
        self.city_search.setFixedWidth(250)
        self.city_search.setToolTip(_("Enter at least 3 characters"))
        self.city_search.setToolTipDuration(2000)
        
        search_button = QPushButton()
        search_button.setText(_("Search"))
        search_button.clicked.connect(self.search_city)

        # Crear QTableView y modelo
        self.table_view = QTableView()
        self.model = QStandardItemModel(0, 5)  # 0 filas, 5 columnas
        self.model.setHorizontalHeaderLabels([_("Lat"), _("Lon"), _("City"), _("Country"), _("State")])
        self.table_view.setModel(self.model)
        self.table_view.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)  # No editable
        self.table_view.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)

        # Conectar el evento de doble clic
        self.table_view.doubleClicked.connect(self.save_row_data)

        # Configurar el comportamiento de las columnas
        header = self.table_view.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)  # Lat
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)  # Lon
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)  # City (ocupa el espacio restante)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)  # Country
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)  # State

        # Establecer anchos fijos para las columnas
        self.table_view.setColumnWidth(0, 100)  # Lat
        self.table_view.setColumnWidth(1, 100)  # Lon
        self.table_view.setColumnWidth(3, 70)  # Country
        self.table_view.setColumnWidth(4, 70)  # State

        # Incorpora contenido al layout
        self.addWidget(label_city, 0, 0, Qt.AlignmentFlag.AlignRight)
        self.addWidget(self.city_search, 0, 1, Qt.AlignmentFlag.AlignCenter)
        self.addWidget(search_button, 0, 2, Qt.AlignmentFlag.AlignLeft)
        self.addWidget(self.table_view, 1, 0, 1, 3)

    def search_city(self):
        city_name = self.city_search.text()
        if len(city_name) < 3:
            QMessageBox.warning(None, _("Error"), _("Enter at least 3 characters"))
            return

        api_url = "http://api.openweathermap.org/geo/1.0/direct"
        params = {
            "q": city_name,
            "limit": 15,
            "appid": OWN_API_KEY
        }
 
        try:
            response = requests.get(api_url, params=params)
            if response.status_code == 200:
                data = response.json()
                # print(data) # Si se necesita depurar
                # Procesar y mostrar los datos en la tabla
                self.update_table(data)
            else:
                QMessageBox.critical(None, _("Error"), _("API Error: {code}").format(code=response.status_code))
        except requests.RequestException as e:
            QMessageBox.critical(None, _("Error"), _("Request failed: {error}").format(error=e))

    def update_table(self, data):
        # Limpiar el modelo antes de agregar nuevos datos
        self.model.setRowCount(0)

        for item in data:
            lat_item = QStandardItem(str(item["lat"]))
            lon_item = QStandardItem(str(item["lon"]))
            city_item = QStandardItem(item["name"])
            country_item = QStandardItem(item["country"])
            state_item = QStandardItem(item.get("state", ""))

            # Agregar fila al modelo
            self.model.appendRow([lat_item, lon_item, city_item, country_item, state_item])

    def save_row_data(self, index):
        # Obtener los datos de la fila seleccionada
        row = index.row()
        lat = self.model.item(row, 0).text()
        lon = self.model.item(row, 1).text()
        name = self.model.item(row, 2).text()
        country = self.model.item(row, 3).text()
        state = self.model.item(row, 4).text()

    
        # Convertir el array a JSON y guardarlo en QSettings
        city_array = [lat, lon, name, country, state]
        self.settings.setValue("city", json.dumps(city_array))

        # Si la ubicación automática está habilitada, deshabilitarla y advertir al usuario
        if self.settings.value("autoloc", False, type=bool):
            self.settings.setValue("autoloc", False)
            QMessageBox.warning(
                None,
                _("Automatic location disabled"),
                _("Automatic location has been disabled because a city was manually selected.")
            )

        self.settings.sync()

        QMessageBox.information(None, _("Info"), _("City data saved successfully!"))
        
        # Emitir la señal para notificar que los datos han sido guardados
        self.city_saved.emit()
