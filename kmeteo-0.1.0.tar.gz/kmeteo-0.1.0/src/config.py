#!/usr/bin/env python3

# Copyright (C) 2025 Carlos Suárez (bitseater@gmail.com)
# SPDX-License-Identifier: GPL-3.0-or-later
#
# This file is part of KMeteo.
# KMeteo is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3
# of the License, or (at your option) any later version.
#
# KMeteo is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

# Valores iniciales de la aplicación

import os
import shlex
import sys
from constants import APP_ID
from PyQt6.QtCore import QSettings

def get_settings():
    settings = QSettings(APP_ID, "kmeteo");
    if settings.contains("ini"):
        print("Settings already exist")
    else:
        print("Creating settings")
        settings.setValue("ini", False)
        settings.setValue("units", "metric")
        settings.setValue("minimized", False)
        settings.setValue("interval", 7200)
        settings.setValue("autoloc", False)
        settings.setValue("startonboot", False)
        settings.setValue("mycity", "")
        settings.setValue("width", 640)
        settings.setValue("height", 480)
        settings.sync()
    return settings

def get_autostart_desktop_path():
    return os.path.join(os.path.expanduser("~/.config/autostart"), f"{APP_ID}.desktop")


def get_autostart_exec():
    if len(sys.argv) > 0 and os.path.isabs(sys.argv[0]) and os.path.exists(sys.argv[0]):
        return f'{shlex.quote(sys.executable)} {shlex.quote(os.path.abspath(sys.argv[0]))}'
    return APP_ID


def update_autostart(enabled: bool):
    autostart_dir = os.path.dirname(get_autostart_desktop_path())
    os.makedirs(autostart_dir, exist_ok=True)
    path = get_autostart_desktop_path()
    if enabled:
        desktop_content = f"""[Desktop Entry]
Type=Application
Name=KMeteo
GenericName=KMeteo
Comment=Forecast App for desktop
Exec={get_autostart_exec()}
Icon={APP_ID}
Terminal=false
StartupNotify=true
X-GNOME-Autostart-enabled=true
Hidden=false
Categories=Education;Science;
"""
        with open(path, "w", encoding="utf-8") as desktop_file:
            desktop_file.write(desktop_content)
    else:
        if os.path.exists(path):
            os.remove(path)
    