#!/bin/bash
# Development helper script for KMeteo - 2025

# Define variables
PACKAGE="io.gitlab.bitseater.kmeteo"
TEMPLATE=po/$PACKAGE.pot
FILES=po/*.po

# Colors for presentation
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

header() {
    echo -e "${BLUE}=======================================${NC}"
    echo -e "${BLUE}   KMeteo Development Helper Script    ${NC}"
    echo -e "${BLUE}=======================================${NC}"
}

check_dependencies() {
    for cmd in meson ninja xgettext msgmerge; do
        if ! command -v "$cmd" &> /dev/null; then
            echo -e "${RED}Error: '$cmd' is not installed.${NC}"
            exit 1
        fi
    done
}

usage()
{
header
cat << EOF
This script simplifies the development workflow for KMeteo.
It handles compilation, installation, and translation updates.

usage: $0 options

OPTIONS:
   -b Build
   -c Compile
   -d Debug
   -e Execute
   -f Flatpak build/install
   -h Show this message
   -l List source files
   -r Register GSettings schemas
   -t Translate
   -u Uninstall (requires 'build' directory)
EOF
}

# Search strings to translate and update po files
translate()
{
    echo -e "${BLUE}Updating translation strings...${NC}"
    MYVAR=$(find . -type f \( -name "*.py" -o -name "*.qml" -o -name "*.metainfo.xml.in" -o -name "*.desktop.in" \))
    xgettext --keyword=_ --escape -o $TEMPLATE $MYVAR
    for f in po/*.po
        do
            [ -e "$f" ] || continue
            msgmerge -v $f $TEMPLATE --update --backup=none
            echo -e "${GREEN}$f updated.${NC}"
        done
}

# Compile with meson / ninja
compile()
{
    echo -e "${BLUE}Configuring and building project...${NC}"
    if [ ! -d "build" ]; then
        meson setup --prefix /usr/ build
    else
        meson setup --prefix /usr/ build --reconfigure
    fi
    meson compile -C build
}

# Build and install
build(){
    echo -e "${BLUE}Installing application to system...${NC}"
    sudo meson install -C build
}

# Debug mode
debug(){
    if [ ! -d "build" ]; then
        echo -e "${RED}Error: Build directory not found. Run with -c first.${NC}"
        return
    fi
    echo -e "${YELLOW}Running in debug mode...${NC}"
    G_MESSAGES_DEBUG=all ./build/src/$PACKAGE
}

# Run mode
run(){
    if [ -f "build/src/$PACKAGE" ]; then
        ./build/src/$PACKAGE
    elif [ -f "build/$PACKAGE" ]; then
        ./build/$PACKAGE
    else
        echo -e "${RED}Error: Executable not found. Build the project first.${NC}"
        exit 1
    fi
}

# Flatpak build and install
flatpak_build(){
    echo -e "${BLUE}Building Flatpak package...${NC}"
    flatpak-builder --user --install --force-clean build-dir flatpak/io.gitlab.bitseater.kmeteo.yml
}

# Uninstall
uninstall(){
    if [ ! -d "build" ]; then
        echo -e "${RED}Error: Build directory not found.${NC}"
        exit 1
    fi
    echo -e "${YELLOW}Uninstalling...${NC}"
    sudo ninja -C build uninstall
    echo -e "${BLUE}Removing cache files...${NC}"
    rm -rvf $HOME/.cache/$PACKAGE
    echo -e "${BLUE}Updating icon cache...${NC}"
    sudo update-icon-caches /usr/share/icons/hicolor/
    echo -e "${GREEN}Uninstall finished.${NC}"
}

# List sources files alphabetically
list(){
    echo -e "${BLUE}Source files:${NC}"
    find . -type f \( -name "*.py" -o -name "*.qml" \) | sort
}

# Register or update schemas
register(){
    echo -e "${BLUE}Registering GSettings schemas...${NC}"
    sudo cp data/$PACKAGE.gschema.xml /usr/share/glib-2.0/schemas/
    sudo glib-compile-schemas /usr/share/glib-2.0/schemas/
    echo -e "${GREEN}Schemas registered successfully.${NC}"
}

check_dependencies

# Menu options
if [ $# -eq 0 ]; then usage; exit 1; fi

while getopts "bcdefhlrtu" OPTION
do
    case $OPTION in
        b)
            compile
            build
            exit 0
            ;;
        c)
            compile
            exit 0
            ;;
        d)
            debug
            exit 1
            ;;
        e)
            run
            exit 0
            ;;
        f)
            flatpak_build
            exit 0
            ;;
        h)
            usage
            exit 0
            ;;
        l)
            list
            exit 0
            ;;
        t)
            translate
            exit 0
            ;;
        r)
            register
            exit 0
            ;;
        u)
            uninstall
            exit 0
            ;;
        ?)
            usage
            exit 0
            ;;
    esac
done
