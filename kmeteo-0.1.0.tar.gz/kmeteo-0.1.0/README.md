# KMeteo    ![Logo de KMeteo](data/logo.png)

### Know the forecast of the next hours & days.

Developed with Python & Qt, using OpenWeatherMap API (https://openweathermap.org/)

### Features:

- Current weather, with information about temperature, pressure, wind speed and direction, sunrise & sunset.
- Forecast for next hours.
- Forecast for next days.
- Choose your units.
- Choose your city.
- Awesome maps with weather info.
- System tray indicator.

## Compilation and Installation

KMeteo uses the Meson build system.

### Prerequisites

Ensure you have the following dependencies installed:
- Python 3
- PyQt6
- requests
- Meson and Ninja
- gettext (for translations)

### Using the quick script

The easiest way for local development is using the provided `quick.sh` helper:
- `./quick.sh -c` to compile.
- `./quick.sh -b` to compile and install.
- `./quick.sh -d` to run in debug mode.
- `./quick.sh -e` to execute the built binary.

### Standard Meson commands

Alternatively, you can use Meson directly:

```bash
meson setup build --prefix=/usr
meson compile -C build
sudo meson install -C build
```

### Install KMeteo

You can install KMeteo on Debian and derivatives manually from.

**[KMeteo releases](https://gitlab.com/bitseater/kmeteo/-/releases)**

or

**[KMeteo repository](https://gitlab.com/bitseater/kmeteo/-/packages)**


###  Screenshots

![Screenshot 1](data/screenshots/captura_1.png)

![Screenshot 2](data/screenshots/captura_2.png)

![Screenshot 3](data/screenshots/captura_3.png)

