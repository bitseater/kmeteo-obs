## Contributing to KMeteo

KMeteo is a forecast application written in Python and Qt. We are grateful for any contribution you can make.

## Reporting a bug

You can add a new issue to reporting a bug, ask for enhancements and new features on
[our issue section at Gitlab](https://gitlab.com/bitseater/kmeteo/-/issues).

## Translating Meteo

You can translate KMeteo to your language. Simply [download the Meteo pot file](https://gitlab.com/bitseater/kmeteo/-/blob/master/po/io.gitlab.bitseater.kmeteo.pot), use your favorite editor (Lokalize, PoEdit, ...) to create translation and send it opening a [Merge Request](https://gitlab.com/bitseater/kmeteo/-/merge_requests).

## Licensing

Contributions should be licensed under the GNU GPL v3.